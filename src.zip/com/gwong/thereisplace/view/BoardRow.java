package com.gwong.thereisplace.view;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.gwong.thereisaplace.R;
import com.gwong.thereisaplace.activity.BaseActivity;

public class BoardRow extends ArrayAdapter<String> {
	private final Activity context;
	private final ArrayList<String> name;
	private final ArrayList<Bitmap> imageId;
	private final ArrayList<String> msg;
	private final ArrayList<String> date;
	private final ArrayList<String> count;

	public BoardRow(Activity context, ArrayList<String> name, ArrayList<Bitmap> imageId, ArrayList<String> msg, ArrayList<String> date, ArrayList<String> count) {
		super(context, R.layout.board_row, name);
		this.context = context;
		this.name = name;
		this.imageId = imageId;
		this.msg = msg;
		this.date = date;
		this.count = count;
	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		LayoutInflater inflater = context.getLayoutInflater();
		View rowView = inflater.inflate(R.layout.board_row, null, true);

		// ImageView iv_image = (ImageView)
		// rowView.findViewById(R.id.f_l_iv_image);
		TextView listview_name = (TextView) rowView.findViewById(R.id.board_tv_name);
		TextView listview_msg = (TextView) rowView.findViewById(R.id.board_tv_msg);
		TextView listview_date = (TextView) rowView.findViewById(R.id.board_tv_date);
		TextView listview_reply = (TextView) rowView.findViewById(R.id.board_tv_reply);

		listview_name.setText(name.get(position));
		// iv_image.setImageBitmap(imageId.get(position));
		listview_msg.setText(msg.get(position));
		listview_date.setText(date.get(position));
		listview_reply.setText("��� " + count.get(position) + "��");

		BaseActivity.setGlobalFont(rowView);
		return rowView;
	}
}
