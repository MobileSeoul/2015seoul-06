package com.gwong.thereisplace.view;

import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.gwong.thereisaplace.R;
import com.gwong.thereisaplace.activity.BaseActivity;

public class ReplyRow extends ArrayAdapter<String> {
	private final Activity context;
	private final ArrayList<String> replyMsg;
	private final ArrayList<String> replyDate;

	public ReplyRow(Activity context, ArrayList<String> replyMsg,
			ArrayList<String> replyDate) {
		super(context, R.layout.reply_row, replyMsg);
		this.context = context;
		this.replyMsg = replyMsg;
		this.replyDate = replyDate;

	}

	@Override
	public View getView(int position, View view, ViewGroup parent) {
		LayoutInflater inflater = context.getLayoutInflater();
		View rowView = inflater.inflate(R.layout.reply_row, null, true);

		TextView listview_msg = (TextView) rowView
				.findViewById(R.id.listview_replyMsg);
		TextView listview_date = (TextView) rowView
				.findViewById(R.id.listview_replyDate);

		listview_msg.setText(replyMsg.get(position));
		listview_date.setText(replyDate.get(position));

		BaseActivity.setGlobalFont(rowView);
		return rowView;
	}
}
