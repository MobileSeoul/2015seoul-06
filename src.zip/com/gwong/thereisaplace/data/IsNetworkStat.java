package com.gwong.thereisaplace.data;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class IsNetworkStat {
	public static boolean isNetworkStat(Context context) {
		ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		NetworkInfo lte_4g = manager.getNetworkInfo(ConnectivityManager.TYPE_WIMAX);
		boolean blte_4g = false;
		if (lte_4g != null)
			blte_4g = lte_4g.isConnected();
		if (mobile != null) {
			if (mobile.isConnected() || wifi.isConnected() || blte_4g)
				return true;
		} else {
			if (wifi.isConnected() || blte_4g)
				return true;
		}

		AlertDialog.Builder dlg = new AlertDialog.Builder(context);
		dlg.setTitle("��Ʈ��ũ ����");
		dlg.setMessage("��Ʈ��ũ ���¸� Ȯ���� �ֽʽÿ�.");
//		dlg.setIcon(R.drawable.icon);
		dlg.setNegativeButton("Ȯ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				dialog.dismiss();
			}
		});
		dlg.show();
		return false;
	}
}
