package com.gwong.thereisaplace.activity;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.gwong.thereisaplace.R;
import com.gwong.thereisaplace.data.GlobalVar;
import com.gwong.thereisaplace.data.IsNetworkStat;
import com.gwong.thereisplace.view.ReplyRow;

public class Content extends BaseActivity {
	private static String imgUrl = GlobalVar.SERVER_ADDRESS + "/uploads/";
	private static String search_tag = "searchId";
	private static String reply_tag = "reply";
	private String stationName;
	private String stationLine;
	private String id;
	String replyMsg;
	
	
	private String writerS, msgS, dateS;
	private Bitmap image;
	private Bitmap bmImg;
	
	private TextView writer;
	private TextView msg;
	private TextView date;
	private ImageView img;
	private StrictMode.ThreadPolicy policy;
	private ScrollView scrollview;
	private EditText replyText;
	private Button replyBtn;

	private ReplyRow adapter;
	private ArrayList<String> arReplyMsg;
	private ArrayList<String> arReplyDate;
	private ListView list;

	private ProgressDialog progDialog;
	private int mValue;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.content_activity);

		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setBackgroundDrawable(new ColorDrawable(GlobalVar.BACKGROUND_COLOR));
		getActionBar().setDisplayShowHomeEnabled(false);

		policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		Intent intent = getIntent();
		stationName = (String) intent.getStringExtra(GlobalVar.EXTRA_NAME);
		stationLine = (String) intent.getStringExtra(GlobalVar.EXTRA_LINE);
		id = (String) intent.getStringExtra(GlobalVar.EXTRA_ID);
		this.setTitle(stationName);

		int titleId = getResources().getIdentifier("action_bar_title", "id", "android");
		TextView tv = (TextView) findViewById(titleId);
		tv.setTextColor(getResources().getColor(R.color.white));
		tv.setTypeface(GlobalVar.TYPEFACE);

		writer = (TextView) findViewById(R.id.content_tv_name);
		msg = (TextView) findViewById(R.id.content_tv_msg);
		date = (TextView) findViewById(R.id.content_tv_date);
		img = (ImageView) findViewById(R.id.content_iv_img);
		replyText = (EditText) findViewById(R.id.content_et_replyText);
		replyBtn = (Button) findViewById(R.id.content_btn_reply);

		final Handler h = new Handler() {
			public void handleMessage(Message msg) {
				progDialog.dismiss();
				img.setImageBitmap(bmImg);
				writer.setText("�͸�");
				date.setText(dateS);
				Content.this.msg.setText(msgS);
				// ����Ʈ�� ����
				adapter = new ReplyRow(Content.this, arReplyMsg, arReplyDate);
				adapter.notifyDataSetChanged();
				list = (ListView) findViewById(R.id.content_lv_reply);
				list.setAdapter(adapter);
				list.setDivider(new ColorDrawable(GlobalVar.BACKGROUND_COLOR));
				list.setDividerHeight(2);
				
			}
		};

		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				Content.this.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						progDialog = new ProgressDialog(Content.this, R.style.dialog);
						progDialog.setCancelable(false);
						progDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
						progDialog.setMessage("Uploading");
						progDialog.show();
					}
				});

				try {
					update();
					updateReply();
					bmImg = null;

					if (IsNetworkStat.isNetworkStat(Content.this)) {
						URL url = new URL(imgUrl + stationLine + "_" + id + ".jpg");
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
						conn.setDoInput(true);
						conn.connect();
						InputStream is = conn.getInputStream();
						bmImg = BitmapFactory.decodeStream(is);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				h.sendEmptyMessage(0);
			}
		});
		t.start();

		replyBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (replyText.getText().toString().equals("")) {
					Toast.makeText(getApplicationContext(), "����� �Է����ּ���.", Toast.LENGTH_SHORT).show();
					return;
				}

				final Handler h = new Handler() {
					public void handleMessage(Message msg) {
						progDialog.dismiss();
						// ����Ʈ�� ����
						adapter = new ReplyRow(Content.this, arReplyMsg, arReplyDate);
						adapter.notifyDataSetChanged();
						list = (ListView) findViewById(R.id.content_lv_reply);
						list.setAdapter(adapter);
						list.setDivider(new ColorDrawable(GlobalVar.BACKGROUND_COLOR));
						list.setDividerHeight(2);
						replyText.setText("");
					}
				};

				Thread t = new Thread(new Runnable() {
					@Override
					public void run() {
						Content.this.runOnUiThread(new Runnable() {
							@Override
							public void run() {
								progDialog = new ProgressDialog(Content.this, R.style.dialog);
								progDialog.setCancelable(false);
								progDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
								progDialog.setMessage("Uploading");
								progDialog.show();
							}
						});

						try {
							replyMsg = replyText.getText().toString();
							URL url = new URL(GlobalVar.SERVER_ADDRESS + "/reply.php?" + "tag=" + URLEncoder.encode(reply_tag, "UTF-8") + "&stationLine=" + URLEncoder.encode(stationLine, "UTF-8")
									+ "&id=" + URLEncoder.encode(id, "UTF-8") + "&replyMsg=" + URLEncoder.encode(replyMsg, "UTF-8"));
							url.openStream();
							updateReply();
							
						} catch (Exception e) {
							e.printStackTrace();
						}
						h.sendEmptyMessage(0);
					}
				});
				t.start();
			}
		});
	}

	public void setContentView(int viewId) {
		View view = LayoutInflater.from(this).inflate(viewId, null);
		BaseActivity.setGlobalFont(view);
		super.setContentView(view);
	}

	@Override
	protected void onResume() {
		super.onResume();
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
	}

	public void update() {
		try {
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			factory.setNamespaceAware(true);
			XmlPullParser xpp = factory.newPullParser();
			URL server = new URL(GlobalVar.SERVER_ADDRESS + "/" + URLEncoder.encode(stationLine + "_" + id + ".xml", "UTF-8"));
			InputStream is = server.openStream();
			xpp.setInput(is, "UTF-8");

			int eventType = xpp.getEventType();

			while (eventType != XmlPullParser.END_DOCUMENT) {
				if (eventType == XmlPullParser.START_TAG) {
					if (xpp.getName().equals("id")) {
						id = xpp.nextText();
					} else if (xpp.getName().equals("writer")) {
						writerS = xpp.nextText();
					} else if (xpp.getName().equals("msg")) {
						msgS = xpp.nextText();
					} else if (xpp.getName().equals("reg_date")) {
						dateS = xpp.nextText();
					}
				}
				eventType = xpp.next();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void updateReply() {
		// �ʱ�ȭ
		arReplyMsg = new ArrayList<String>();
		arReplyDate = new ArrayList<String>();
		// ������ �Է�
		try {
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			factory.setNamespaceAware(true);
			XmlPullParser xpp = factory.newPullParser();
			URL server = new URL(GlobalVar.SERVER_ADDRESS + "/" + URLEncoder.encode(stationLine + "_" + id + ".xml", "UTF-8"));
			InputStream is = server.openStream();
			xpp.setInput(is, "UTF-8");

			int eventType = xpp.getEventType();

			while (eventType != XmlPullParser.END_DOCUMENT) {
				if (eventType == XmlPullParser.START_TAG) {
					if (xpp.getName().equals("replyMsg")) {
						arReplyMsg.add(xpp.nextText());
					} else if (xpp.getName().equals("replyDate")) {
						arReplyDate.add(xpp.nextText());
					}
				}
				eventType = xpp.next();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
