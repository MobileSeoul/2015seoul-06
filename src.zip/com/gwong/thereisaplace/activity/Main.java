package com.gwong.thereisaplace.activity;

import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import uk.co.senab.photoview.PhotoViewAttacher;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.StrictMode;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;

import com.gwong.thereisaplace.R;
import com.gwong.thereisaplace.data.GlobalVar;
import com.gwong.thereisaplace.data.SubwayInfo;
import com.gwong.thereisplace.view.RankRow;
import com.gwong.thereisplace.view.SearchDialog;

public class Main extends BaseActivity {
	private final static String RANK_XML = "rank.xml";
	private final static String RANKDIALOG_TITLE = "   �ǽð� �� ����";
	private final int RANK_CNT = 7;

	private int dpi;

	private ImageView imageView;
	private PhotoViewAttacher attacher;
	private ProgressDialog progDialog;
	private SearchDialog searchDialog;
	private AlertDialog rankDialog;

	private ArrayList<String> items;
	private StrictMode.ThreadPolicy policy;

	String[] names;
	String[] lines;
	int cnt;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);
		GlobalVar.BACKGROUND_COLOR = getResources().getColor(R.color.background);

		getActionBar().setBackgroundDrawable(new ColorDrawable(GlobalVar.BACKGROUND_COLOR));
		getActionBar().setDisplayShowHomeEnabled(false);

		policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		dpi = getResources().getDisplayMetrics().densityDpi;
		imageView = (ImageView) findViewById(R.id.main_iv_subway);
		attacher = new PhotoViewAttacher(imageView);
		attacher.setScaleType(ScaleType.CENTER);
		attacher.dpi = dpi;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();

		if (id == R.id.main_mnu_search) {
			searchDialog = new SearchDialog(Main.this);
			items = new ArrayList<String>();

			for (int i = 0; i < SubwayInfo.stationInfo.size(); i++) {
				items.add(SubwayInfo.stationInfo.get(i).getName());
			}

			searchDialog.show();
			searchDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
			searchDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
		} else if (id == R.id.main_mnu_rank) {
			names = new String[RANK_CNT];
			lines = new String[RANK_CNT];
			cnt = 0;
			final Handler h = new Handler() {
				public void handleMessage(Message msg) {
					progDialog.dismiss();
				}
			};

			Thread t = new Thread(new Runnable() {
				@Override
				public void run() {
					Main.this.runOnUiThread(new Runnable() {
						@Override
						public void run() {
							progDialog = new ProgressDialog(Main.this, R.style.dialog);
							progDialog.setCancelable(false);
							progDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
							progDialog.setMessage("Loading");
							progDialog.show();
						}
					});

					Looper.prepare();
					try {
						XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
						factory.setNamespaceAware(true);
						XmlPullParser xpp = factory.newPullParser();
						URL server = new URL(GlobalVar.SERVER_ADDRESS + "/" + URLEncoder.encode(RANK_XML, "UTF-8"));
						InputStream is = server.openStream();
						xpp.setInput(is, "UTF-8");
						int eventType = xpp.getEventType();

						while (eventType != XmlPullParser.END_DOCUMENT) {
							if (eventType == XmlPullParser.START_TAG) {
								if (xpp.getName().equals(GlobalVar.TAG_NAME)) {
									names[cnt] = xpp.nextText();
								} else if (xpp.getName().equals(GlobalVar.TAG_LINE)) {
									lines[cnt] = xpp.nextText();
									cnt++;
									if (cnt == RANK_CNT)
										break;
								}
							}
							eventType = xpp.next();
						}

						RankRow adapter = new RankRow(Main.this, R.layout.rank_row, Arrays.asList(names), Arrays.asList(lines));
						AlertDialog.Builder builder = new AlertDialog.Builder(Main.this, R.style.dialog);
						builder.setAdapter(adapter, null);

						TextView content = new TextView(Main.this);
						content.setText(RANKDIALOG_TITLE);
						content.setTextColor(GlobalVar.BACKGROUND_COLOR);
						content.setTextSize(20);
						content.setTypeface(GlobalVar.TYPEFACE);
						content.setPadding(0, 30, 0, 30);

						builder.setCustomTitle(content);
						builder.setItems(names, new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int index) {
							}
						});
						rankDialog = builder.create();
						rankDialog.show();

						int dividerId = rankDialog.getContext().getResources().getIdentifier("android:id/titleDivider", null, null);
						View divider = rankDialog.findViewById(dividerId);
						divider.setBackgroundColor(GlobalVar.BACKGROUND_COLOR);

						h.sendEmptyMessage(0);
					} catch (Exception e) {
						e.printStackTrace();
					}
					Looper.loop();
				}
			});
			t.start();
		}
		return super.onOptionsItemSelected(item);
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			moveTaskToBack(true);
			finish();
			android.os.Process.killProcess(android.os.Process.myPid());
		}
		return false;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main_menu, menu);
		return true;
	}
}
