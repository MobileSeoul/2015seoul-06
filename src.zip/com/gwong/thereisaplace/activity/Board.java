package com.gwong.thereisaplace.activity;

import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gwong.thereisaplace.R;
import com.gwong.thereisaplace.data.GlobalVar;
import com.gwong.thereisaplace.data.Lines;
import com.gwong.thereisaplace.data.StationInfo;
import com.gwong.thereisaplace.data.SubwayInfo;
import com.gwong.thereisplace.view.BoardRow;
import com.gwong.thereisplace.view.SurroundingStationRow;

public class Board extends BaseActivity {
	private static final int ACT_CLICK_CONTENT = 0;
	private static final int ACT_CLICK_WRITE = 1;
	private static final int ACT_CLICK_MOVE = 2;

	private static String search_tag = "searchAll";
	private static String rank_tag = "rank";
	private String stationName;
	private String stationLine;

	private BoardRow adapter;
	private ArrayList<String> arId;
	private ArrayList<String> arWriter;
	private ArrayList<Bitmap> arImage;
	private ArrayList<String> arMsg;
	private ArrayList<String> arDate;
	private ArrayList<String> arCount;
	private ListView list;

	private StrictMode.ThreadPolicy policy;

	private ProgressDialog progDialog;
	private Context context;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.board_activity);
		context = this.getApplicationContext();

		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setBackgroundDrawable(new ColorDrawable(GlobalVar.BACKGROUND_COLOR));
		getActionBar().setDisplayShowHomeEnabled(false);

		policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		Intent intent = getIntent();
		stationName = (String) intent.getStringExtra(GlobalVar.EXTRA_NAME);
		stationLine = (String) intent.getStringExtra(GlobalVar.EXTRA_LINE);
		stationLine = stationLine.toLowerCase();
		this.setTitle(stationName);

		int titleId = getResources().getIdentifier("action_bar_title", "id", "android");
		TextView tv = (TextView) findViewById(titleId);
		tv.setTextColor(getResources().getColor(R.color.white));
		tv.setTypeface(GlobalVar.TYPEFACE);

		updateList();
		try {
			URL url = new URL(GlobalVar.SERVER_ADDRESS + "/rank.php?" + "tag=" + URLEncoder.encode(rank_tag, "UTF-8") + "&" + GlobalVar.TAG_NAME + "=" + URLEncoder.encode(stationName, "UTF-8") + "&"
					+ GlobalVar.TAG_LINE + "=" + URLEncoder.encode(stationLine, "UTF-8"));
			url.openStream();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	AdapterView.OnItemClickListener mItemClickListener = new AdapterView.OnItemClickListener() {
		@SuppressWarnings("unchecked")
		public void onItemClick(AdapterView parent, View view, int position, long id) {
			if (parent == list) {
				Intent intent = new Intent(view.getContext(), Content.class);
				intent.putExtra(GlobalVar.EXTRA_NAME, stationName);
				intent.putExtra(GlobalVar.EXTRA_LINE, stationLine);
				intent.putExtra(GlobalVar.EXTRA_ID, arId.get(position));
				startActivityForResult(intent, ACT_CLICK_CONTENT);
			}
		}
	};

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case ACT_CLICK_CONTENT:
			updateList();
			break;
		case ACT_CLICK_WRITE:
			updateList();
			break;
		case ACT_CLICK_MOVE:
			break;
		}
	}

	public void updateList() {
		arId = new ArrayList<String>();
		arWriter = new ArrayList<String>();
		arImage = new ArrayList<Bitmap>();
		arMsg = new ArrayList<String>();
		arDate = new ArrayList<String>();
		arCount = new ArrayList<String>();

		final Handler h = new Handler() {
			public void handleMessage(Message msg) {
				progDialog.dismiss();
				adapter = new BoardRow(Board.this, arWriter, arImage, arMsg, arDate, arCount);
				adapter.notifyDataSetChanged();
				list = (ListView) findViewById(R.id.board_lv_list);
				list.setAdapter(adapter);
				list.setDivider(new ColorDrawable(GlobalVar.BACKGROUND_COLOR));
				list.setDividerHeight(2);
				list.setOnItemClickListener(mItemClickListener);
			}
		};

		Thread t = new Thread(new Runnable() {
			public void run() {
				Board.this.runOnUiThread(new Runnable() {
					public void run() {
						progDialog = new ProgressDialog(Board.this, R.style.dialog);
						progDialog.setCancelable(false);
						progDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
						progDialog.setMessage("Loading");
						progDialog.show();
					}
				});

				try {
					URL url = new URL(GlobalVar.SERVER_ADDRESS + "/search.php?" + "tag=" + URLEncoder.encode(search_tag, "UTF-8") + "&" + GlobalVar.TAG_NAME + "="
							+ URLEncoder.encode(stationName, "UTF-8") + "&" + GlobalVar.TAG_LINE + "=" + URLEncoder.encode(stationLine, "UTF-8"));
					url.openStream();
					XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
					factory.setNamespaceAware(true);
					XmlPullParser xpp = factory.newPullParser();
					URL server = new URL(GlobalVar.SERVER_ADDRESS + "/" + URLEncoder.encode(stationName + "_" + stationLine + ".xml", "UTF-8"));
					InputStream is = server.openStream();
					xpp.setInput(is, "UTF-8");

					int eventType = xpp.getEventType();

					while (eventType != XmlPullParser.END_DOCUMENT) {
						if (eventType == XmlPullParser.START_TAG) {
							if (xpp.getName().equals(GlobalVar.TAG_ID)) {
								arId.add(xpp.nextText());
							} else if (xpp.getName().equals(GlobalVar.TAG_WRITER)) {
								arWriter.add(xpp.nextText());
							} else if (xpp.getName().equals(GlobalVar.TAG_MSG)) {
								arMsg.add(xpp.nextText());
							} else if (xpp.getName().equals(GlobalVar.TAG_REGDATE)) {
								arDate.add(xpp.nextText());
							} else if (xpp.getName().equals(GlobalVar.TAG_REPLYCNT)) {
								arCount.add(xpp.nextText());
							}
						}
						eventType = xpp.next();
					}
					h.sendEmptyMessage(0);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		t.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.board_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();

		if (id == R.id.board_mnu_write) {
			Intent intent = new Intent(context, Write.class);
			intent.putExtra(GlobalVar.EXTRA_NAME, stationName);
			intent.putExtra(GlobalVar.EXTRA_LINE, stationLine);
			startActivityForResult(intent, ACT_CLICK_WRITE);
			return true;
		} else if (id == R.id.board_mnu_refresh) {
			updateList();
		} else if (id == R.id.board_mnu_before || id == R.id.board_mnu_next) {
			StationInfo info = null;
			String[] stations = null;
			String[] lines = null;
			int size = 0;

			info = SubwayInfo.findStation(stationName);
			stations = info.getSurroundingStation();
			lines = info.getLine();

			for (int i = 0; i < lines.length; i++) {
				if (Lines.LINES_ENG[Integer.parseInt(lines[i]) - 1].toLowerCase().equals(stationLine)) {
					size = i;
					break;
				}
			}

			StationInfo nextInfo;
			final ArrayList<String> nextNames = new ArrayList<String>();
			final ArrayList<String> nextLines = new ArrayList<String>();
			if (id == R.id.board_mnu_before) {
				nextInfo = SubwayInfo.findStation(stations[size * 2]);
				if (nextInfo == null) {
					Toast.makeText(context, "������ �� �Դϴ�.", Toast.LENGTH_SHORT).show();
					return true;
				}
				for (int i = 0; i < nextInfo.getLine().length; i++) {
					nextNames.add(nextInfo.getName());
					nextLines.add(nextInfo.getLine()[i]);
				}

				if (info.getOffset() % 2 == 1) {
					nextInfo = SubwayInfo.findStation(stations[size * 2 + 1]);
					for (int i = 0; i < nextInfo.getLine().length; i++) {
						nextNames.add(nextInfo.getName());
						nextLines.add(nextInfo.getLine()[i]);
					}
				}
			} else if (id == R.id.board_mnu_next) {
				nextInfo = SubwayInfo.findStation(stations[size * 2 + 1]);
				if (nextInfo == null) {
					Toast.makeText(context, "������ �� �Դϴ�.", Toast.LENGTH_SHORT).show();
					return true;
				}
				for (int i = 0; i < nextInfo.getLine().length; i++) {
					nextNames.add(nextInfo.getName());
					nextLines.add(nextInfo.getLine()[i]);
				}

				if (info.getOffset() % 2 == 0 && info.getOffset() == (size * 2 + 2) && info.getOffset() != 0) {
					nextInfo = SubwayInfo.findStation(stations[size * 2 + 1 + 1]);
					for (int i = 0; i < nextInfo.getLine().length; i++) {
						nextNames.add(nextInfo.getName());
						nextLines.add(nextInfo.getLine()[i]);
					}
				}
			}

			if (nextNames.size() == 1) {
				Intent intent = new Intent(context, Board.class);
				intent.putExtra(GlobalVar.EXTRA_NAME, nextNames.get(0));
				intent.putExtra(GlobalVar.EXTRA_LINE, Lines.LINES_ENG[Integer.parseInt(nextLines.get(0)) - 1].toLowerCase());
				startActivityForResult(intent, ACT_CLICK_MOVE);
				finish();
			} else {
				SurroundingStationRow adapter = new SurroundingStationRow(Board.this, R.layout.rank_row, nextNames, nextLines);
				AlertDialog.Builder builder = new AlertDialog.Builder(Board.this, R.style.dialog);
				builder.setAdapter(adapter, null);

				TextView content = new TextView(Board.this);
				content.setText("�� ����");
				content.setTextColor(GlobalVar.BACKGROUND_COLOR);
				content.setTextSize(20);
				content.setTypeface(GlobalVar.TYPEFACE);
				content.setPadding(0, 30, 0, 30);

				builder.setCustomTitle(content);
				builder.setItems((CharSequence[]) nextNames.toArray(new String[nextNames.size()]), new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int index) {
						Intent intent = new Intent(context, Board.class);
						intent.putExtra(GlobalVar.EXTRA_NAME, nextNames.get(index));
						intent.putExtra(GlobalVar.EXTRA_LINE, Lines.LINES_ENG[Integer.parseInt(nextLines.get(index)) - 1].toLowerCase());
						startActivityForResult(intent, ACT_CLICK_MOVE);
						finish();
					}
				});

				AlertDialog dialog = builder.create();
				dialog.show();

				int dividerId = dialog.getContext().getResources().getIdentifier("android:id/titleDivider", null, null);
				View divider = dialog.findViewById(dividerId);
				divider.setBackgroundColor(GlobalVar.BACKGROUND_COLOR);
			}
		}

		return super.onOptionsItemSelected(item);
	}
}
